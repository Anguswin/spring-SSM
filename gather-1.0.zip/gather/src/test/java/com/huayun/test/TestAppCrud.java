package com.huayun.test;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import com.huayun.dao.AppMapperDao;
import com.huayun.model.App;

public class TestAppCrud {

	SqlSessionFactory ssf;
	
	@Before
	public void init() {
		try {
			InputStream in = 
					Resources.getResourceAsStream("sqlMapConfig.xml");
			ssf = new SqlSessionFactoryBuilder().build(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void findAll() {
		SqlSession session = ssf.openSession();
		AppMapperDao appMapper = session.getMapper(AppMapperDao.class);
		List<App> appList = appMapper.findAll();
		
		for(App app : appList) {
			System.out.println(app);
		}
		session.close();
	}
	
	@Test
	public void count() {
		SqlSession session = ssf.openSession();
		AppMapperDao appMapper = session.getMapper(AppMapperDao.class);
		int c= appMapper.count();
		
		System.out.println(c);
		session.close();
	}
	
	@Test
	public void findById() {
		SqlSession session = ssf.openSession();
		AppMapperDao appMapper = session.getMapper(AppMapperDao.class);
		App app = appMapper.findById(2);
		
		System.out.println(app);
		session.close();
	}
	
	@Test
	public void insertApp() {
		SqlSession session = ssf.openSession();
		AppMapperDao appMapper = session.getMapper(AppMapperDao.class);
		
		App app = new App();
		app.setName("ccc");
		app.setDescribe("DESC");
		app.setLeader("leader");
		app.setContact("con");
		app.setUnit("UNIT");
		
		appMapper.insertApp(app);
		session.commit();
		System.out.println(app);
		session.close();
	}
	
	@Test
	public void updateApp() {
		SqlSession session = ssf.openSession();
		AppMapperDao appMapper = session.getMapper(AppMapperDao.class);
		
		App app = new App();
		app.setName("ccc");
		app.setLeader("ABB");
		
		appMapper.updateApp(app);
		session.commit();
		System.out.println(app);
		session.close();
	}
	
	@Test
	public void delApp() {
		SqlSession session = ssf.openSession();
		AppMapperDao appMapper = session.getMapper(AppMapperDao.class);
		appMapper.delApp(4L);
		session.commit();
		session.close();
	}
}
