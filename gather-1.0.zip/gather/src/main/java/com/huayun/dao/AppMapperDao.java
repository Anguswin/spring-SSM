package com.huayun.dao;

import java.util.List;

import com.huayun.model.App;

public interface AppMapperDao {

	public List<App> findAll();
	
	public int count();
	
	public App findById(int id);
	
	public void insertApp(App app);
	
	public void updateApp(App app);
	
	public void delApp(Long id);
}
