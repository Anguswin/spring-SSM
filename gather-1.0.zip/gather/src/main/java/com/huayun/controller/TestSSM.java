package com.huayun.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.huayun.dao.AppMapperDao;
import com.huayun.model.App;

@Controller
public class TestSSM {
	@Autowired
	private AppMapperDao appMapperDao;

	@RequestMapping("/ssfindAll")
	public String findAll() {
		List<App> appList = appMapperDao.findAll();
		for(App app : appList) {
			System.out.println(app);
		}
		
		return "test";
	}
}
