package com.huayun.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.huayun.model.App;
import com.huayun.service.AppService;

@Controller
public class AppController {

	@Autowired
	private AppService appService;
	
	@RequestMapping("/findAll")
	public String AppList(Model model) {
		List<App> list = appService.findAll();
		model.addAttribute("list",list);
		return "app_list";
	}
}
