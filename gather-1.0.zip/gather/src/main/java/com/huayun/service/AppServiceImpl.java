package com.huayun.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huayun.dao.AppMapperDao;
import com.huayun.model.App;

@Service
public class AppServiceImpl implements AppService{

	@Autowired
	private AppMapperDao appMapper;
	
	@Override
	public List<App> findAll() {
		List<App> appList = appMapper.findAll();
		return appList;
	}

	
	
}
