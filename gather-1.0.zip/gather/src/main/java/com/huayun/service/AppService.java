package com.huayun.service;

import java.util.List;

import com.huayun.model.App;

public interface AppService {

	public List<App> findAll();
}
